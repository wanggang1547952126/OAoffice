package com.qst.goodsmanagement.service;

import com.qst.goodsmanagement.beans.Goods;

import java.util.List;

public interface GoodsService {
    public int addNewGoods(Goods Goods);
    public int deleteGoodsById(int id);
    public List<Goods> getAllGoods();
    public List<Goods> getGoodsByName(String name);
    public int updataGoods(Goods Goods);
}
