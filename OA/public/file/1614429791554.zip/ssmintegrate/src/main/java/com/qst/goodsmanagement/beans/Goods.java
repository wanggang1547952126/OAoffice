package com.qst.goodsmanagement.beans;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Goods {
    private Integer goodid;

    private String goodname;

    private Integer goodprice;

    private Date marketdate;

    private Integer goodnum;

    private Double discount;
}