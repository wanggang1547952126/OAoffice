package com.qst.goodsmanagement.service.impl;

import com.qst.goodsmanagement.beans.Goods;
import com.qst.goodsmanagement.dao.GoodsMapper;
import com.qst.goodsmanagement.service.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("GoodsService")
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    private GoodsMapper GoodsMapper;

    @Override
    public int addNewGoods(Goods Goods) {
        return GoodsMapper.insertSelective(Goods);
    }

    @Override
    public int deleteGoodsById(int id) {
        return GoodsMapper.deleteByPrimaryKey(id);
    }

    @Override
    public List<Goods> getAllGoods() {
        return GoodsMapper.selectAll();
    }

    @Override
    public List<Goods> getGoodsByName(String name) {
        return GoodsMapper.selectByGoodname(name);
    }

    @Override
    public int updataGoods(Goods Goods) {
        return 0;
    }
}
