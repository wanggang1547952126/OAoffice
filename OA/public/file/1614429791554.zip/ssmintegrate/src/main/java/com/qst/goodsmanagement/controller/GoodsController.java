package com.qst.goodsmanagement.controller;

import com.alibaba.fastjson.JSON;
import com.qst.goodsmanagement.beans.Goods;
import com.qst.goodsmanagement.service.impl.GoodsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Controller
@RequestMapping("/goods")
public class GoodsController {

    @Autowired
    private GoodsServiceImpl GoodsService;

    @RequestMapping("/showAllgoods")
    public void showAllgoods(HttpSession session, HttpServletResponse response) throws IOException {
        String jsonString = JSON.toJSONString(GoodsService.getAllGoods());
        response.getWriter().print(jsonString);
    }

    @ResponseBody
    @RequestMapping("/addNewGoods")
    public void addNewGoods(Goods Goods){
        System.out.println(Goods);
        int result = GoodsService.addNewGoods(Goods);
        System.out.println(result);
    }

}
